selenium==4.21.0
pytest==8.2.0
webdriver-manager==4.0.1
pytest-html==3.2.0
pytest-xdist==3.6.1
