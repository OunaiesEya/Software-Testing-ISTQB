from selenium import webdriver
from selenium.webdriver.common.by import By
import time


def main():
    print("=== TEST MANUEL SAUCEDEMO ===")

    # Saisie des identifiants AVANT d'ouvrir le navigateur
    print("Veuillez entrer vos identifiants :")
    username = input("Username: ")
    password = input("Password: ")

    print("\nLancement du navigateur...")

    # Configuration Chrome
    driver = webdriver.Chrome()

    try:
        # Aller sur le site
        driver.get("https://www.saucedemo.com")
        time.sleep(2)

        # Remplir le formulaire
        driver.find_element(By.ID, "user-name").send_keys(username)
        driver.find_element(By.ID, "password").send_keys(password)
        driver.find_element(By.ID, "login-button").click()

        # Attendre et vérifier
        time.sleep(3)

        if "inventory" in driver.current_url:
            print("✅ SUCCÈS: Connecté!")
        else:
            print("❌ ÉCHEC: Non connecté")
            print(f"URL actuelle: {driver.current_url}")

        # Garder ouvert pour inspection
        print("\nNavigateur ouvert - inspectez la page...")
        input("Appuyez sur ENTRÉE pour fermer le navigateur...")

    finally:
        driver.quit()
        print("Test terminé!")


if __name__ == "__main__":
    main()
