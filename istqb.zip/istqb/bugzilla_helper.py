from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import datetime
import os


def reporter_bugzilla_auto(nom_test, erreur, url, prendre_screenshot=True):
    print(f"\n🚀 Création d'un bug pour: {nom_test}")

    # 1️⃣ Créer un nouveau navigateur Chrome (séparé)
    options = webdriver.ChromeOptions()
    options.headless = False  # Obligatoire pour voir la page
    driver = webdriver.Chrome(options=options)

    try:
        # 2️⃣ Aller directement à Bugzilla
        driver.get("https://bugzilla.mozilla.org/enter_bug.cgi")

        wait = WebDriverWait(driver, 20)

        # 3️⃣ Cliquer sur Firefox
        try:
            firefox_btn = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//*[contains(text(), 'Firefox')]"))
            )
            firefox_btn.click()
            print("✅ Firefox sélectionné")
        except:
            print("⚠️ Impossible de sélectionner Firefox automatiquement")

        # 4️⃣ Remplir le formulaire
        try:
            wait.until(EC.presence_of_element_located((By.ID, "short_desc")))
            driver.find_element(By.ID, "short_desc").send_keys(
                f"[Test Auto] Échec: {nom_test}"
            )

            description = f"""Problème détecté par test Selenium automatisé

TEST: {nom_test}
URL: {url}
DATE: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
ERREUR: {str(erreur)[:500]}  # Limité à 500 caractères

STEPS POUR REPRODUIRE:
1. Ouvrir {url}
2. Exécuter le test {nom_test}
3. Observer l'échec

ENVIRONNEMENT:
- Test automatisé Selenium
- Généré automatiquement"""

            driver.find_element(By.ID, "comment").send_keys(description)
            driver.find_element(By.ID, "version").clear()
            driver.find_element(By.ID, "version").send_keys("unspecified")

            print("✅ Formulaire Bugzilla rempli (vérifiez CAPTCHA manuellement)")
        except Exception as e:
            print(f"⚠️ Impossible de remplir le formulaire automatiquement: {e}")

        # 5️⃣ Screenshot optionnel
        if prendre_screenshot:
            os.makedirs("screenshots", exist_ok=True)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            screenshot_path = f"screenshots/erreur_{nom_test}_{timestamp}.png"
            driver.save_screenshot(screenshot_path)
            print(f"🖼 Screenshot sauvegardé: {screenshot_path}")

        print("=" * 50)
        print("⚠️ Étapes manuelles : compléter le CAPTCHA et soumettre le bug")
        print("=" * 50)

        # On **ne ferme pas le navigateur** pour que tu puisses compléter le formulaire
    except Exception as e:
        print(f"❌ Erreur avec Bugzilla: {e}")