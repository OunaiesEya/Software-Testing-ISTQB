from utils.driver_factory import get_driver
from utils.config import BASE_URL, STANDARD_USER, STANDARD_PASSWORD, BAD_PASSWORD
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_login_valid():
    driver = get_driver("chrome")
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys(STANDARD_USER)
    driver.find_element("id", "password").send_keys(STANDARD_PASSWORD)
    driver.find_element("id", "login-button").click()
    assert "inventory" in driver.current_url
    driver.quit()

def test_login_invalid_password():
    driver = get_driver("chrome")
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys(STANDARD_USER)
    driver.find_element("id", "password").send_keys(BAD_PASSWORD)
    driver.find_element("id", "login-button").click()
    assert "Epic sadface" in driver.page_source
    driver.quit()

