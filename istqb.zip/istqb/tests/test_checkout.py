from selenium.webdriver.common.by import By

from tests.test_add_to_cart import login
from utils.driver_factory import get_driver

# AJOUTEZ CET IMPORT
try:
    from bugzilla_reporter import report_to_bugzilla

    BUGZILLA_AVAILABLE = True
except ImportError:
    BUGZILLA_AVAILABLE = False
    print("Bugzilla reporter non disponible")


def test_checkout_process():
    driver = None
    try:
        driver = get_driver("chrome")
        login(driver)

        driver.find_element("id", "add-to-cart-sauce-labs-backpack").click()
        driver.find_element("class name", "shopping_cart_link").click()
        driver.find_element("id", "checkout").click()
        driver.find_element("id", "first-name").send_keys("Eya")
        driver.find_element("id", "last-name").send_keys("Ounaies")
        driver.find_element("id", "postal-code").send_keys("3000")
        driver.find_element("id", "continue").click()

        # CORRECTION: Le mot "Overview" n'existe pas sur cette page
        # Essayez plutôt de vérifier un élément visible
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC

        # Attendre un élément de la page de checkout
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "summary_info"))
        )

        print("Test checkout réussi!")

    except Exception as e:
        print(f'Test checkout échoué: {e}')


        if BUGZILLA_AVAILABLE and driver:
            print("Ouverture de Bugzilla...")
            report_to_bugzilla(
                driver=driver,
                test_name="test_checkout_process",
                error_msg=str(e),
                url=driver.current_url
            )
        else:
            print("Bugzilla non disponible ou driver manquant")

        # Relance l'erreur pour que pytest marque le test comme échoué
        raise

    finally:
        if driver:
            # Gardez le navigateur ouvert pour voir Bugzilla
            input('\n Appuyez sur Entrée pour fermer le navigateur...')
            driver.quit()