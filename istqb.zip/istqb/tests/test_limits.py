from utils.driver_factory import get_driver
from utils.config import BASE_URL, STANDARD_PASSWORD
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_username_min_length():
    driver = get_driver("chrome")
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys("a")
    driver.find_element("id", "password").send_keys(STANDARD_PASSWORD)
    driver.find_element("id", "login-button").click()
    assert "Epic sadface" in driver.page_source
    driver.quit()

def test_username_max_length():
    driver = get_driver("chrome")
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys("a"*255)
    driver.find_element("id", "password").send_keys(STANDARD_PASSWORD)
    driver.find_element("id", "login-button").click()
    assert "Epic sadface" in driver.page_source
    driver.quit()
