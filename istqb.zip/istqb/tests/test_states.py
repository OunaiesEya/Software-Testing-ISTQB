from utils.driver_factory import get_driver
from utils.config import BASE_URL, STANDARD_USER, STANDARD_PASSWORD
import time
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_navigation_states():
    driver = get_driver("chrome")
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys(STANDARD_USER)
    driver.find_element("id", "password").send_keys(STANDARD_PASSWORD)
    driver.find_element("id", "login-button").click()
    driver.find_element("class name", "shopping_cart_link").click()
    driver.back()
    time.sleep(1)
    assert "inventory" in driver.current_url
    driver.quit()
