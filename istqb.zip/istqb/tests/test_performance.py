from utils.driver_factory import get_driver
import time
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_homepage_load_time():
    driver = get_driver("chrome")
    start = time.time()
    driver.get("https://www.saucedemo.com")
    load_time = time.time() - start
    assert load_time < 3
    driver.quit()
