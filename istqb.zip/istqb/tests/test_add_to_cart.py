from utils.driver_factory import get_driver
from utils.config import BASE_URL, STANDARD_USER, STANDARD_PASSWORD
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def login(driver):
    driver.get(BASE_URL)
    driver.find_element("id", "user-name").send_keys(STANDARD_USER)
    driver.find_element("id", "password").send_keys(STANDARD_PASSWORD)
    driver.find_element("id", "login-button").click()

def test_add_one_item():
    driver = get_driver("chrome")
    login(driver)
    driver.find_element("id", "add-to-cart-sauce-labs-backpack").click()
    driver.find_element("class name", "shopping_cart_link").click()

