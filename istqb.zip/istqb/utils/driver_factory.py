from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager


def get_driver(browser="chrome"):
    """Retourne une instance de WebDriver pour le navigateur spécifié"""
    if browser == "chrome":
        # CORRECTION: Créer chrome_options avant de l'utiliser
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument("--ignore-certificate-errors")

        service = ChromeService(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        return driver

    elif browser == "firefox":
        # ... votre code firefox ...
        pass
