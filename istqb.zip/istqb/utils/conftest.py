import pytest
from bugzilla_helper import reporter_bugzilla_auto

@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()


    if report.when == "call" and report.failed:
        driver = item.funcargs.get("driver")  # Nom du fixture Selenium
        nom_test = item.name
        erreur = report.longreprtext
        url = getattr(driver, "current_url", "URL inconnue")

        if driver:
            reporter_bugzilla_auto(driver, nom_test, erreur, url)
        else:
            print(f"Aucun driver trouvé pour le test {nom_test}, impossible de créer le bug automatiquement")
