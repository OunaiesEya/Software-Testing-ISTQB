from selenium.webdriver.common.by import By
import datetime
import time


def report_to_bugzilla(driver, test_name, error_msg, url=""):

    print(f"\n BUGZILLA: Ouverture pour '{test_name}'")

    try:
        # Sauvegarder fenêtre actuelle
        original_window = driver.current_window_handle

        # Nouvel onglet
        driver.execute_script("window.open('');")
        driver.switch_to.window(driver.window_handles[-1])

        # Aller sur Bugzilla
        driver.get("https://bugzilla.mozilla.org/enter_bug.cgi")
        time.sleep(3)

        # Chercher Firefox
        firefox_found = False
        for element in driver.find_elements(By.TAG_NAME, "a"):
            if "Firefox" in element.text:
                element.click()
                firefox_found = True
                break

        if not firefox_found:
            # Fallback
            driver.find_element(By.XPATH, "//*[contains(text(), 'Firefox')]").click()

        time.sleep(2)

        # Remplir formulaire
        driver.find_element(By.ID, "short_desc").send_keys(
            f"[SELENIUM TEST] Échec: {test_name}"
        )

        description = f"""Test automatisé SauceDemo échoué

Test: {test_name}
Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
URL: {url}
Erreur: {error_msg}

STEPS POUR REPRODUIRE:
1. Aller sur https://www.saucedemo.com
2. Se connecter (standard_user/secret_sauce)
3. Ajouter 'Sauce Labs Backpack' au panier
4. Aller au panier
5. Cliquer Checkout
6. Remplir informations (Eya/Ounaies/3000)
7. Cliquer Continue
8. Observer l'échec: l'élément 'summary_info' n'apparaît pas

ENVIRONNEMENT:
- Selenium WebDriver
- Chrome
- Python pytest

NOTE: Ce bug a été généré automatiquement par le framework de test."""

        driver.find_element(By.ID, "comment").send_keys(description)

        print("✅ FORMULAIRE BUGZILLA REMPLI!")
        print("⚠️  ÉTAPES MANUELLES:")
        print("   1. Aller à l'onglet Bugzilla")
        print("   2. Compléter le CAPTCHA")
        print("   3. Cliquer 'Submit Bug'")
        print("   4. Noter le numéro du bug")

    except Exception as bugzilla_error:
        print(f"❌ Erreur Bugzilla: {bugzilla_error}")

    finally:
        # Retour à la fenêtre originale
        try:
            driver.switch_to.window(original_window)
        except:
            pass