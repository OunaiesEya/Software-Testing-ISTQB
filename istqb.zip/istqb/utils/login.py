import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import datetime

# Imports
from utils.driver_factory import get_driver


# AJOUTEZ CETTE FONCTION BUGZILLA DIRECTEMENT DANS LE FICHIER
def open_bugzilla_for_failure(browser, error_msg):
    """Ouvre Bugzilla quand un test cross-browser échoue"""
    print(f"\n🚨 BUGZILLA pour {browser.upper()}: {error_msg}")

    try:
        # Créer un driver Chrome juste pour Bugzilla
        from selenium import webdriver
        bug_driver = webdriver.Chrome()

        # Aller sur Bugzilla
        bug_driver.get("https://bugzilla.mozilla.org/enter_bug.cgi")
        time.sleep(3)

        # Chercher Firefox
        for element in bug_driver.find_elements(By.TAG_NAME, "a"):
            if "Firefox" in element.text:
                element.click()
                break

        time.sleep(2)

        # Remplir formulaire
        bug_driver.find_element(By.ID, "short_desc").send_keys(
            f"[CROSS-BROWSER] Driver {browser} non disponible"
        )

        description = f"""Échec de test cross-browser

Browser testé: {browser}
Test: Login SauceDemo
Erreur: {error_msg}
Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

PROBLÈME:
Le driver Selenium pour {browser} n'a pas pu être créé.
La fonction get_driver('{browser}') a retourné None.

CAUSES POSSIBLES:
1. Driver {browser} non installé
2. WebDriverManager ne trouve pas le driver
3. Problème de configuration

ACTION REQUISE:
1. Installer le driver {browser}
2. Vérifier WebDriverManager
3. Tester manuellement

ENVIRONNEMENT:
- Selenium WebDriver
- Python pytest
- Test cross-browser SauceDemo

NOTE: Bug généré automatiquement."""

        bug_driver.find_element(By.ID, "comment").send_keys(description)

        print(f"✅ Bugzilla ouvert pour {browser}")
        print("⚠️  Complétez le CAPTCHA et soumettez le bug")

        # Laisser ouvert pour démonstration
        time.sleep(10)

        bug_driver.quit()

    except Exception as e:
        print(f"❌ Erreur Bugzilla: {e}")


browsers = ["chrome", "firefox", "edge"]


@pytest.mark.parametrize("browser", browsers)
def test_login_cross_browser(browser):
    """Test de login cross-browser avec reporting Bugzilla"""

    driver = None

    try:
        print(f"\n🌐 Démarrage test {browser.upper()}...")

        # 1. Essayer de créer le driver
        driver = get_driver(browser)

        # VÉRIFICATION CRITIQUE
        if driver is None:
            error_msg = f"Driver {browser} non disponible - get_driver() a retourné None"
            print(f"❌ {browser}: {error_msg}")

            # ✅ OUVERTURE BUGZILLA !
            open_bugzilla_for_failure(browser, error_msg)

            # Relancer une erreur pour pytest
            raise AttributeError(error_msg)

        # 2. Test normal
        driver.get("https://www.saucedemo.com")
        print(f"✅ {browser}: Page chargée")

        driver.find_element(By.ID, "user-name").send_keys("standard_user")
        driver.find_element(By.ID, "password").send_keys("secret_sauce")
        driver.find_element(By.ID, "login-button").click()

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, "inventory_list"))
        )

        print(f"✅ {browser}: Login réussi")

    except AttributeError as e:
        # Erreur "driver is None" - déjà gérée par Bugzilla
        print(f"🔴 {browser}: Test impossible - driver non disponible")
        raise  # Marquer comme échoué

    except Exception as e:
        # Autre erreur pendant le test
        print(f"❌ {browser}: Erreur pendant le test - {e}")

        # Ouvre Bugzilla aussi pour les autres erreurs
        if driver:  # Si le driver existe mais le test échoue
            try:
                open_bugzilla_for_failure(browser, str(e))
            except:
                pass

        raise  # Marquer comme échoué

    finally:
        if driver:
            time.sleep(1)
            driver.quit()
        print(f"📝 {browser}: Test terminé\n")