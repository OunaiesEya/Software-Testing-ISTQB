BASE_URL = "https://www.saucedemo.com"
STANDARD_USER = "standard_user"
STANDARD_PASSWORD = "secret_sauce"
BAD_PASSWORD = "wrong_pass"
