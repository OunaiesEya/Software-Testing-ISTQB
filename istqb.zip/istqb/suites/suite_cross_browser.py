import pytest
from utils.driver_factory import get_driver
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto

browsers = ["chrome", "firefox", "edge"]

@pytest.fixture(params=browsers)
def driver(request):
    driver = get_driver(request.param)
    yield driver
    driver.quit()
def test_login_cross_browser(driver):
    driver.get("https://www.saucedemo.com")
    driver.find_element("id", "user-name").send_keys("standard_user")
    driver.find_element("id", "password").send_keys("secret_sauce")
    driver.find_element("id", "login-button").click()
    assert "inventory" in driver.current_url

