from tests.test_login import test_login_valid, test_login_invalid_password
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_suite_smoke():
    test_login_valid()
    test_login_invalid_password()
