from tests.test_performance import test_homepage_load_time
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_suite_performance():
    test_homepage_load_time()
