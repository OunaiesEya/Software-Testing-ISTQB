from tests.test_login import test_login_valid, test_login_invalid_password, test_login_empty_fields
from tests.test_add_to_cart import test_add_one_item, test_add_multiple_items
from tests.test_checkout import test_checkout_process
from tests.test_limits import test_username_min_length, test_username_max_length
from tests.test_states import test_navigation_states
from tests.test_performance import test_homepage_load_time
from bugzilla_helper import reporter_bugzilla_auto


USE_BUGZILLA = reporter_bugzilla_auto
def test_suite_regression():
    test_login_valid()
    test_login_invalid_password()
    test_login_empty_fields()
    test_add_one_item()
    test_add_multiple_items()
    test_checkout_process()
    test_username_min_length()
    test_username_max_length()
    test_navigation_states()
    test_homepage_load_time()
